NinjaHyrax

    NinjaHyrax is a lightweight macOS floating web browser written in Python with PyObjC.
    It creates a small, borderless WKWebView window that stays on top of all applications, allowing you to access the web without leaving full-screen apps or switching contexts.

Features

    Borderless, floating WKWebView browser

    Toggles between left and right sides of the screen when pressing the t key

    emi-transparent overlay that stays on top of all other windows

    Hidden from the Dock using Accessory Activation Policy

    Simple launcher script for delayed start

Usage

    1. Install requirements

    Make sure you have Python 3 with PyObjC installed:

    pip3 install pyobjc

    2. Run the launcher

    The launcher waits 20 seconds before starting the browser (so you can prepare other apps first):

    python3 launcher.py


    The floating NinjaHyrax window will appear with DuckDuckGo loaded.

    3. Controls

    Press t → Moves the browser window between left and right sides of the screen

    The window stays always on top

    Use the web normally inside the embedded view

How it avoids runtime blacklists

    Many testing and monitoring softwares perform runtime scans for known blacklisted applications by:

    Checking process names or bundle IDs

    Looking for dock icons or menu bar entries

    Scanning running apps against a known blacklist

    NinjaHyrax avoids these detections by:

    Running as a plain Python process (python3), which is not usually blacklisted.

    Using Accessory Activation Policy, which removes its Dock icon and menu bar entry.

    Having no static signature, since it is just a Python script and not a precompiled binary.

    Creating its window at the system level with PyObjC, without needing an app bundle identifier that could be flagged.

    Note: This is for educational purposes. Circumventing proctoring or monitoring software may violate academic or workplace integrity policies.

Project Structure
    .
    ├── NinjaHyrax.py   # Core floating browser
    ├── launcher.py     # 20-second delay launcher
    └── README.md       # Documentation