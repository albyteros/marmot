import time
import subprocess
import os

print("Launching the browser in 20 seconds")
time.sleep(20)

browser_path = os.path.abspath("NinjaHyrax.py")
subprocess.Popen(["python3", browser_path])
print("hyrax bit.")
