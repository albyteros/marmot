# Andrew watters
# 1/24/2026

import os
import subprocess
import json
from datetime import datetime

DATA_FILE = "last_played.json"

# Safe load of JSON
games_data = {}
if os.path.exists(DATA_FILE):
    try:
        if os.path.getsize(DATA_FILE) > 0:
            with open(DATA_FILE, "r") as f:
                games_data = json.load(f)
    except json.JSONDecodeError:
        print("Warning: last_played.json is corrupted. Starting fresh.")
        games_data = {}

# Helper to display stars (0-10 rating -> 0-5 stars)
def star_string(rating):
    if rating is None:
        return "No rating"
    stars = rating / 2  # convert 10-scale to 5 stars
    full = int(stars)
    half = 1 if stars - full >= 0.5 else 0
    empty = 5 - full - half
    return "★"*full + "½"*half + "☆"*empty

def get_folders():
    return [f for f in os.listdir(".") if os.path.isdir(f) and f != "__pycache__" and not f.endswith(".py")]

def sort_folders(folders):
    def key(f):
        lp = games_data.get(f, {}).get("last_played")
        if not lp or lp == "Never":
            return datetime.min
        try:
            return datetime.strptime(lp, "%Y-%m-%d %H:%M")
        except:
            return datetime.min
    return sorted(folders, key=key, reverse=True)

def show_folders(folders):
    if not folders:
        print("No game folders found!")
        return
    
    # Calculate max length for folder names for alignment
    max_len = max(len(f) for f in folders)
    
    # Header
    print("\n{:<4} {:<{width}} {:<17} {:<10}".format("No.", "Game Name", "Last Played", "Rating", width=max_len))
    print("-" * (6 + max_len + 17 + 10))
    
    # Rows
    for i, f in enumerate(folders, 1):
        data = games_data.get(f, {})
        lp = data.get("last_played", "Never")
        rating = data.get("rating", None)
        stars = star_string(rating)
        print("{:<4} {:<{width}} {:<17} {:<10}".format(i, f, lp, stars, width=max_len))

def choose_exe(folder):
    exe_files = [f for f in os.listdir(folder) if f.lower().endswith(".exe")]
    if not exe_files:
        print("No .exe found in that folder!")
        return None
    elif len(exe_files) > 1:
        print("Multiple .exe files found:")
        for i, f in enumerate(exe_files, 1):
            print(f"{i}. {f}")
        choice = input("Choose number: ")
        try:
            return exe_files[int(choice)-1]
        except:
            print("Invalid choice")
            return None
    else:
        return exe_files[0]

# Main loop
while True:
    folders = get_folders()
    if not folders:
        print("No game folders found!")
        break

    folders = sort_folders(folders)
    show_folders(folders)

    print("\nCommands:")
    print("  l = launch a game")
    print("  r = rate a game")
    print("  q = quit")
    cmd = input("> ").strip().lower()

    if cmd == "q":
        break
    elif cmd == "l":
        choice = input("Enter game number to launch: ")
        try:
            idx = int(choice) - 1
            folder = folders[idx]
        except:
            print("Invalid number")
            continue

        exe_file = choose_exe(folder)
        if exe_file:
            exe_path = os.path.join(folder, exe_file)
            print(f"Launching {folder}...")
            subprocess.Popen(exe_path)
            # Update last played
            if folder not in games_data:
                games_data[folder] = {}
            games_data[folder]["last_played"] = datetime.now().strftime("%Y-%m-%d %H:%M")
            with open(DATA_FILE, "w") as f:
                json.dump(games_data, f, indent=4)

    elif cmd == "r":
        choice = input("Enter game number to rate: ")
        try:
            idx = int(choice) - 1
            folder = folders[idx]
        except:
            print("Invalid number")
            continue

        rating_input = input("Enter rating from 0 to 10: ")
        try:
            rating = float(rating_input)
            if 0 <= rating <= 10:
                if folder not in games_data:
                    games_data[folder] = {}
                games_data[folder]["rating"] = rating
                with open(DATA_FILE, "w") as f:
                    json.dump(games_data, f, indent=4)
                print(f"Rated {folder} as {star_string(rating)}")
            else:
                print("Rating must be between 0 and 10")
        except:
            print("Invalid rating")
    else:
        print("Unknown command")
