from Cocoa import (
    NSApplication, NSApp, NSWindow, NSBackingStoreBuffered, NSColor, NSObject,
    NSApplicationActivationPolicyAccessory, NSScreen, NSWindowStyleMaskBorderless,
)
from WebKit import WKWebView
from AppKit import NSScreenSaverWindowLevel
from Foundation import NSURL, NSURLRequest, NSTimer
import Quartz  # for keyboard events

# Virtual key code for 't' on macOS keyboard
VK_T = 17

class NinjaHyraxWindow(NSWindow):
    def canBecomeKeyWindow(self):
        return True

    def canBecomeMainWindow(self):
        return True

class NinjaHyraxDelegate(NSObject):
    def applicationDidFinishLaunching_(self, notification):
        NSApp.setActivationPolicy_(NSApplicationActivationPolicyAccessory)

        self.screen_frame = NSScreen.mainScreen().frame()
        self.window_width = 400
        self.window_height = 300
        self.margin = 40

        self.is_left = True
        origin_x = self.margin
        origin_y = self.screen_frame.size.height - self.window_height - self.margin
        rect = ((origin_x, origin_y), (self.window_width, self.window_height))

        self.window = NinjaHyraxWindow.alloc().initWithContentRect_styleMask_backing_defer_(
            rect,
            NSWindowStyleMaskBorderless,
            NSBackingStoreBuffered,
            False
        )
        self.window.setBackgroundColor_(NSColor.whiteColor())
        self.window.setAlphaValue_(0.2)

        # Set high window level to stay on top
        self.window.setLevel_(NSScreenSaverWindowLevel)

        self.window.makeKeyAndOrderFront_(None)

        self.webview = WKWebView.alloc().initWithFrame_(rect)
        url = NSURL.URLWithString_("https://duckduckgo.com")
        request = NSURLRequest.requestWithURL_(url)
        self.webview.loadRequest_(request)
        self.window.setContentView_(self.webview)

        NSApp.activateIgnoringOtherApps_(True)

        self.t_pressed_last = False  # Track last key state

        # Setup a repeating timer to poll keyboard state every 0.1 sec
        NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(
            0.1, self, "checkKeyPress:", None, True
        )

    def checkKeyPress_(self, timer):
        # Get current key state of 't'
        key_state = Quartz.CGEventSourceKeyState(Quartz.kCGEventSourceStateHIDSystemState, VK_T)
        if key_state and not self.t_pressed_last:
            # 't' was just pressed
            self.toggle_window_position()
        self.t_pressed_last = key_state

    def toggle_window_position(self):
        if self.is_left:
            origin_x = self.screen_frame.size.width - self.window_width - self.margin
        else:
            origin_x = self.margin

        origin_y = self.screen_frame.size.height - self.window_height - self.margin

        self.window.setFrameOrigin_((origin_x, origin_y))
        self.window.makeKeyAndOrderFront_(None)
        self.is_left = not self.is_left


if __name__ == "__main__":
    app = NSApplication.sharedApplication()
    delegate = NinjaHyraxDelegate.alloc().init()
    NSApp().setDelegate_(delegate)
    app.run()
