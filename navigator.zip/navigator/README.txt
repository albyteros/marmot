lightweight Python-based game launcher that automatically tracks when you last played each game and lets you rate them on a 0–10 scale. Designed for folders full of Windows games that aren't on steam, or if you prefer less bloat than steam. It can also be used for any .exe, so if you hate those pesky apps opening up on startup you can now open them in bulk through here.








how to run

Make sure Python 3 is installed
Place the script in your main games directory
Run:

python launcher.py








Folder structure must look as follows

GameLauncher/
├── Game1/
│   └── game1.exe
├── Game2/
│   └── game2.exe
├── Software/
│   └── software.exe
├── last_played.json
└── launcher.py







Features

Auto-detects game folders in the current directory
Launches games directly from the terminal
Tracks last played time for each game
Allows rating games from 0–10 with a star-based display
Sorts games by most recently played
Uses persistent storage via last_played.json